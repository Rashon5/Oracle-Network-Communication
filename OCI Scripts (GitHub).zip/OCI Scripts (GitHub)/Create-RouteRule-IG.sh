#!/bin/bash

# Variables
compartment_id="ocid1.compartment.oc1..aaaaaaaarr4tb2wytxku2xtocrj4hztpje5dup6ck4lavnfvy354tr6p2foa"
vcn_id="ocid1.vcn.oc1.iad.amaaaaaaqsornxyatitbfh2ehd5ot7gobtfbcaky5szqblvwpaqknckf7clq"
route_table_id="ocid1.routetable.oc1.iad.aaaaaaaa6akfin4d7eltyujot5g7ebvcjhfkzbfckpelpzxh3njpze7zd6sa"
internet_gateway_name="internet-gw-mod-3"

# Retrieve Internet Gateway OCID
internet_gateway_id=$(oci network internet-gateway list --compartment-id $compartment_id --vcn-id $vcn_id --query "data[?\"display-name\"=='$internet_gateway_name'].id | [0]" --raw-output)

if [ -z "$internet_gateway_id" ]; then
  echo "Error: Internet Gateway with display name $internet_gateway_name not found in compartment $compartment_id."
  exit 1
fi

echo "Retrieved Internet Gateway OCID: $internet_gateway_id"

# Add Route Rule to Route Table
oci network route-table update \
    --rt-id $route_table_id \
    --route-rules '[{"cidrBlock":"0.0.0.0/0","networkEntityId":"'"$internet_gateway_id"'"}]' \
    --force

echo "Route rule to allow traffic to 0.0.0.0/0 via Internet Gateway $internet_gateway_id added to the route table $route_table_id."

# Verify the Route Table
oci network route-table get --rt-id $route_table_id
