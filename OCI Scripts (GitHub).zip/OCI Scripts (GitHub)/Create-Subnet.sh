#!/bin/bash

compartment_id="ocid1.compartment.oc1..OCID" # Insert your compartment ID (Networking)
vcn_id="ocid1.vcn.oc1.iad.OCID" # Insert VCN ID
route_table_id="ocid1.routetable.oc1.iad.OCID" # Insert Route Table ID
security_list_id="ocid1.securitylist.oc1.iad.OCID" # Insert Security List ID
availability_domain="ZWGx:US-ASHBURN-AD-1" # Insert Availability Domain (One allowed by free tier Instance)

# Creates Finance subnet
oci network subnet create \
    --compartment-id $compartment_id \
    --vcn-id $vcn_id \
    --cidr-block 10.0.1.0/24 \
    --display-name finance-subnet \
    --prohibit-public-ip-on-vnic false \
    --route-table-id $route_table_id \
    --security-list-ids '["'"$security_list_id"'"]' \
    --availability-domain $availability_domain

# Creates Sales subnet
oci network subnet create \
    --compartment-id $compartment_id \
    --vcn-id $vcn_id \
    --cidr-block 10.0.2.0/24 \
    --display-name sales-subnet \
    --prohibit-public-ip-on-vnic false \
    --route-table-id $route_table_id \
    --security-list-ids '["'"$security_list_id"'"]' \
    --availability-domain $availability_domain