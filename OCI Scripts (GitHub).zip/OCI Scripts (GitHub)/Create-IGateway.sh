#!/bin/bash

compartment_id="ocid1.compartment.oc1..OCID" # Insert your compartment ID
vcn_id="ocid1.vcn.oc1.iad.OCID" # Insert your VCN ID

# Create Internet Gateway
oci network internet-gateway create \
    --compartment-id $compartment_id \
    --vcn-id $vcn_id \
    --display-name internet-gw-mod-3 \
    --is-enabled true