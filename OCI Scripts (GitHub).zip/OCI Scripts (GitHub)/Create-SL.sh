#!/bin/bash

# Script doesn't seem to work, must be done in OCI GUI, or upload in Oracle CloudShell
export COMPARTMENT_OCID="ocid1.compartment.oc1..OCID" # Enter your compartment ID (Networking)
export VCN_OCID="ocid1.vcn.oc1.iad.OCID" # Enter VCN ID
export MY_IP_ADDRESS=$(curl -s https://api.ipify.org) # Your own public IP

# Debug Information
echo "Compartment OCID: $COMPARTMENT_OCID"
echo "VCN OCID: $VCN_OCID"
echo "My IP Address: $MY_IP_ADDRESS"

# Security List for sl-sales
# Ingress allows SSH from your IP to any VCN resource
# Egress allows all outbound traffic within VCN to Internet
oci network security-list create --debug \
    --compartment-id $COMPARTMENT_OCID \
    --vcn-id $VCN_OCID \
    --display-name "sl-sales" \
    --egress-security-rules '[
        {
            "destination": "0.0.0.0/0",
            "destinationType": "CIDR_BLOCK",
            "protocol": "all",
            "isStateless": false
        }
    ]' \
    --ingress-security-rules '[
        {
            "source": "'$MY_IP_ADDRESS'/32",
            "sourceType": "CIDR_BLOCK",
            "protocol": "6",
            "tcpOptions": {
                "destinationPortRange": {
                    "min": 22,
                    "max": 22
                }
            },
            "isStateless": false
        }
    ]'

# Security List for sl-finance
# Ingress allows SSH from your IP to any VCN resource (My IP)
# Second Ingress allows HTTP access from 10.0.2.0/24 Subnet to any resource within VCN
# Egress allows all outbound traffic within VCN to Internet
oci network security-list create --debug \
    --compartment-id $COMPARTMENT_OCID \
    --vcn-id $VCN_OCID \
    --display-name "sl-finance" \
    --egress-security-rules '[
        {
            "destination": "0.0.0.0/0",
            "destinationType": "CIDR_BLOCK",
            "protocol": "all",
            "isStateless": false
        }
    ]' \
    --ingress-security-rules '[
        {
            "source": "'$MY_IP_ADDRESS'/32",
            "sourceType": "CIDR_BLOCK",
            "protocol": "6",
            "tcpOptions": {
                "destinationPortRange": {
                    "min": 22,
                    "max": 22
                }
            },
            "isStateless": false
        },
        {
            "source": "10.0.2.0/24",
            "sourceType": "CIDR_BLOCK",
            "protocol": "6",
            "tcpOptions": {
                "destinationPortRange": {
                    "min": 80,
                    "max": 80
                }
            },
            "isStateless": false
        }
    ]'