#!/bin/bash

# Compartment ID for networking resources
oci network vcn create \
    --compartment-id ocid1.compartment.oc1..aaaaaaaarr4tb2wytxku2xtocrj4hztpje5dup6ck4lavnfvy354tr6p2foa \
    --display-name vcn-mod3 \
    --cidr-block 10.0.0.0/16 \