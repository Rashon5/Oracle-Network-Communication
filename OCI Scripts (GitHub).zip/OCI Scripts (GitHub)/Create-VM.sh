#!/bin/bash

# NOTICE: When creating instances through script, go on GUI and press Start on the instance 2-3 times
# SSH will NOT work right away, the above line is required to do so

# Variables
compute_compartment_id="ocid1.compartment.oc1..computeOCID"  # Update with your resourcesCompute compartment OCID
network_compartment_id="ocid1.compartment.oc1..networkOCID"  # Update with your resourcesNetworking compartment OCID
vcn_name="vcn-mod3" # Insert name of VCN created in Create-VCN.sh
subnet_name="finance-subnet" # Insert name of Subnet created in Create-Subnet.sh, replace with "sales-subnet" to create sales-vm under its subnet
instance_name="finance-vm" # Insert sales-vm in sales-subnet after creating finance-vm
shape="VM.Standard.E2.1.Micro"
ssh_key_prefix="webservervs" # Replace with private key (will be downloaded) - May make a different private key for each instance or not
wait_time=60  # Time to wait in seconds before checking SSH availability

# Generate SSH key pair if not already present
if [ ! -f "${ssh_key_prefix}.key" ]; then
    ssh-keygen -t rsa -b 2048 -f ${ssh_key_prefix}.key -N ""
fi

# Retrieve VCN OCID
vcn_id=$(oci network vcn list --compartment-id "$network_compartment_id" --query "data[?\"display-name\"=='$vcn_name'].id | [0]" --raw-output)

if [ -z "$vcn_id" ]; then
  echo "Error: VCN with display name $vcn_name not found in compartment $network_compartment_id."
  exit 1
fi

echo "Retrieved VCN OCID: $vcn_id"

# Retrieve Subnet OCID
subnet_id=$(oci network subnet list --compartment-id "$network_compartment_id" --vcn-id "$vcn_id" --query "data[?\"display-name\"=='$subnet_name'].id | [0]" --raw-output)

if [ -z "$subnet_id" ]; then
  echo "Error: Subnet with display name $subnet_name not found in compartment $network_compartment_id."
  exit 1
fi

echo "Retrieved Subnet OCID: $subnet_id"

# Retrieve the Availability Domain
availability_domain=$(oci iam availability-domain list --compartment-id "$compute_compartment_id" --query 'data[0].name' --raw-output)

if [ -z "$availability_domain" ]; then
  echo "Error: Could not retrieve availability domain."
  exit 1
fi

echo "Retrieved Availability Domain: $availability_domain"

# Manually set the Image ID for Oracle Linux 7.9-2024.06.30-0
image_id="ocid1.image.oc1.iad.aaaaaaaaibl6w2vwkohcehuhudlg7oilpyfovulvpvxe2hj6yc4o2vbr5hea"  # Replace with the correct image ID for Oracle Linux 7.9-2024.06.30-0

# Create Instance
oci compute instance launch \
    --compartment-id "$compute_compartment_id" \
    --availability-domain "$availability_domain" \
    --shape "$shape" \
    --display-name "$instance_name" \
    --subnet-id "$subnet_id" \
    --assign-public-ip true \
    --metadata "{\"ssh_authorized_keys\": \"$(cat "${ssh_key_prefix}.key.pub")\"}" \
    --image-id "$image_id"

echo "Instance $instance_name created in compartment $compute_compartment_id, using shape $shape, and subnet $subnet_id
